/*
 * Name of Student/Programmers:
 * Balanza, Clian
 * Morano, Ian
 * Oka, Shaun Gerald
 * Orlino, Maki
 * Perdido, Jiro
 * Torres, Kate
 * CLASS CODE & Schedule: 9308A/9308B & 2:30pm - 3:30pm MTH (9308A) / 1:30pm - 3:00 pm TF (9308B)
 * Date: March , 2024
 * Instructor: Dale D. Miguel
 */

// code ni Shaun
package edu.slu.prog2;

import java.util.Scanner;

public class FractionTester {
    static Scanner kbd = new Scanner(System.in);

    public static void main(String[] args) {
        FractionTester groupTester;
        try {
            groupTester = new FractionTester();
            groupTester.run();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        System.exit(0);
    }

    public void run() throws Exception {
        Fraction result = new Fraction();
        Fraction[] typeOfFraction1;
        byte choice;
        System.out.println("Welcome to Fraction Tester!");
        while (true) {
            typeOfFraction1 = new Fraction[1];
            choice = arithmeticMenu();
            switch (choice) {
                case 1 -> result = readFraction(typeOfFraction1).add(readFraction(typeOfFraction1));
                case 2 -> result = readFraction(typeOfFraction1).subtract(readFraction(typeOfFraction1));
                case 3 -> result = readFraction(typeOfFraction1).multiplyBy(readFraction(typeOfFraction1));
                case 4 -> result = readFraction(typeOfFraction1).divideBy(readFraction(typeOfFraction1));
                case 5 -> result = readFraction(typeOfFraction1).simplify();
                case 6 -> {
                    System.out.println("""
                            Thank you for using Fraction Tester!
                            Tester exiting...""");
                    return;
                }
            }
            System.out.printf("Result: %s or %.2f%n", result.simplify(), result.toDouble());
            System.out.print("Please press enter to continue...");
            kbd.nextLine();
        }
    }

    public int readNumber(String prompt, int min, int max) {
        int number = 0;
        boolean validInput = false;
        while (!validInput) {
            System.out.printf("%s", prompt);
            try {
                number = Integer.parseInt(kbd.nextLine());
                if (number >= min && number <= max) {
                    validInput = true;
                } else {
                    System.out.printf("Please enter a number with a minimum of %d and a maximum of %d.%n", min, max);
                }
            } catch (NumberFormatException exception) {
                System.out.println("ERROR: Invalid number.");
                System.out.println("Please try again.");
            }
        }
        return number;
    }

    public int readNonZeroNumber(String prompt, int min, int max) {
        int number = 0;
        boolean validInput = false;
        while (!validInput) {
            System.out.printf("%s", prompt);
            try {
                number = Integer.parseInt(kbd.nextLine());
                if (number == 0) {
                    throw new NumberFormatException();
                } else if (number >= min && number <= max) {
                    validInput = true;
                } else {
                    System.out.printf("Please enter a number with a minimum of %d and a maximum of %d.%n", min, max);
                }
            } catch (NumberFormatException exception) {
                System.out.println("ERROR: Invalid number.");
                System.out.println("Please try again.");
            }
        }
        return number;
    }

    public Fraction readFraction(Fraction[] typeOfFraction1) {
        Fraction result = new Fraction();
        byte type = fractionTypeMenu();
        int numerator;
        int denominator;
        int wholeNumber;
        System.out.println("Please enter a fraction");
        switch (type) {
            case 1:
                numerator = readNumber("Please enter numerator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                denominator = readNonZeroNumber("Please enter denominator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                result = new Fraction(numerator, denominator);
                typeOfFraction1[0] = result;
                break;
            case 2:
                wholeNumber = readNumber("Please enter whole number: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                numerator = readNumber("Please enter numerator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                denominator = readNonZeroNumber("Please enter denominator: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
                result = new MixedFraction(wholeNumber, numerator, denominator);
                System.out.println(typeOfFraction1[0] instanceof Fraction);
                if (typeOfFraction1[0] instanceof Fraction) {
                    result = ((MixedFraction) result).toFraction();
                }
                break;
        }
        return result;
    }

    private byte arithmeticMenu() {
        byte choice;
        System.out.println("""
                * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
                |    Please choose:              |
                |    1.) Add                     |
                |    2.) Subtract                |
                |    3.) Multiply                |
                |    4.) Divide                  |
                |    5.) Simplify                |
                |    6.) Exit                    |
                * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *""");
        choice = (byte) readNumber("Please enter number of choice: ", 1, 6);
        return choice;
    }

    private byte fractionTypeMenu() {
        byte type;
        System.out.println("""
                * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *
                |    Please choose fraction:     |
                |    1.) Im/Proper               |
                |    2.) Mixed                   |
                * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ *""");
        type = (byte) readNumber("Please enter number of choice: ", 1, 2);
        return type;
    }

}
